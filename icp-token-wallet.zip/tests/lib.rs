
#[cfg(test)]
mod tests {
    use super::*;
    use ic_cdk::export::Principal;

    #[test]
    fn test_send_tokens() {
        let from = Principal::anonymous().to_string();
        let to = "recipient".to_string();
        WALLETS.with(|wallets| {
            let mut wallets = wallets.borrow_mut();
            wallets.insert(from.clone(), Wallet { balance: 100 });
        });
        let result = send_tokens(to.clone(), 50);
        assert!(result.is_ok());
        WALLETS.with(|wallets| {
            let wallets = wallets.borrow();
            assert_eq!(wallets.get(&from).unwrap().balance, 50);
            assert_eq!(wallets.get(&to).unwrap().balance, 50);
        });
    }

    #[test]
    fn test_receive_tokens() {
        let account_id = Principal::anonymous().to_string();
        receive_tokens(100);
        WALLETS.with(|wallets| {
            let wallets = wallets.borrow();
            assert_eq!(wallets.get(&account_id).unwrap().balance, 100);
        });
    }

    #[test]
    fn test_get_balance() {
        let account_id = Principal::anonymous().to_string();
        WALLETS.with(|wallets| {
            let mut wallets = wallets.borrow_mut();
            wallets.insert(account_id.clone(), Wallet { balance: 100 });
        });
        assert_eq!(get_balance(account_id), 100);
    }
}
