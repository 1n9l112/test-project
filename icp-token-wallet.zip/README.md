
# ICP Token Wallet

## Overview
This project is a Rust-based token wallet for the Internet Computer Protocol (ICP) blockchain. It supports sending and receiving IRCRC2 tokens and includes basic wallet security features.

## Setup

1. **Install Rust**: Follow the instructions at [rust-lang.org](https://www.rust-lang.org/).
2. **Install ICP Development Tools**: Follow the ICP developer documentation for setup.
3. **Clone the Repository**: `git clone https://github.com/your-repo/icp-token-wallet.git`
4. **Navigate to Project Directory**: `cd icp-token-wallet`

## Running the Wallet

1. **Start Local ICP Test Network**: Follow the ICP documentation to start a local test network.
2. **Deploy Smart Contracts**: Use the provided scripts or ICP commands to deploy the smart contracts.
3. **Run the Wallet**: Use Rust commands to interact with the wallet functions.

## Testing

1. **Run Unit Tests**: `cargo test`
2. **Verify Functionalities**: Ensure all tests pass and functionalities work as expected.

## Code Explanation
- `src/lib.rs`: Contains the main smart contract code.
- `tests`: Contains unit tests for the smart contract functions.

## Contact
For any queries, contact [hr@quadbtech.com](mailto:hr@quadbtech.com) with the subject "Rust Blockchain Developer Task" for prioritized assistance.
