
use ic_cdk_macros::{query, update};
use ic_cdk::export::candid::{CandidType, Deserialize};
use std::cell::RefCell;

type Balance = u64;
type AccountId = String;

#[derive(CandidType, Deserialize, Clone, Default)]
struct Wallet {
    balance: Balance,
}

thread_local! {
    static WALLETS: RefCell<std::collections::HashMap<AccountId, Wallet>> = RefCell::new(std::collections::HashMap::new());
}

#[update]
fn send_tokens(to: AccountId, amount: Balance) -> Result<(), String> {
    let from = ic_cdk::caller().to_string();
    WALLETS.with(|wallets| {
        let mut wallets = wallets.borrow_mut();
        let from_wallet = wallets.entry(from.clone()).or_default();
        if from_wallet.balance < amount {
            return Err("Insufficient balance".to_string());
        }
        from_wallet.balance -= amount;
        let to_wallet = wallets.entry(to).or_default();
        to_wallet.balance += amount;
        Ok(())
    })
}

#[update]
fn receive_tokens(amount: Balance) {
    let account_id = ic_cdk::caller().to_string();
    WALLETS.with(|wallets| {
        let mut wallets = wallets.borrow_mut();
        let wallet = wallets.entry(account_id).or_default();
        wallet.balance += amount;
    })
}

#[query]
fn get_balance(account_id: AccountId) -> Balance {
    WALLETS.with(|wallets| {
        let wallets = wallets.borrow();
        wallets.get(&account_id).map_or(0, |wallet| wallet.balance)
    })
}
